module.exports.generateSql = function () {
  return `drop table users;`;
};
